package dz5.guitar;

import java.util.Arrays;

public class Guitar {
private String producer;
private Struna[] struns;
private Skvorechnik baraban; 
private int countStrun;
private String type;


public Guitar(String producer, int countStrun, String type, Skvorechnik bar, Struna[] kom){
this.producer = producer;
this.countStrun = countStrun;
this.type = type;
this.struns = new Struna[countStrun];
this.struns = kom;
this.baraban=bar;
}

public void nastroika(){
	for (int i=0; i<struns.length; i++)	struns[i].setAccuracy(100);
}


public void changeStruns(int index, Struna b){
struns[index]=b;	

}

public void showStruns(){
for (int i=0; i<countStrun;i++){
	System.out.println((i+1)+" ������: "+struns[i].toString());	
}
	
}

public String getProducer() {
	return producer;
}


public void setProducer(String producer) {
	this.producer = producer;
}


public Struna[] getStruns() {
	return struns;
}


public void setStruns(Struna[] struns) {
	this.struns = struns;
}


public Skvorechnik getBaraban() {
	return baraban;
}


public void setBaraban(Skvorechnik baraban) {
	this.baraban = baraban;
}


public int getCountStrun() {
	return countStrun;
}


public void setCountStrun(int countStrun) {
	this.countStrun = countStrun;
}


public String getType() {
	return type;
}


public void setType(String type) {
	this.type = type;
}


@Override
public String toString() {
	return "Guitar [�������������]:" + producer + ", [���]:" + type + ", [���������� �����]" + countStrun;
}


public void play(int num,int count){
	for(int i=0; i<count; i++) {
		struns[num-1].setIznos(struns[num-1].getIznos()-0.001); //��������� ��������� ������
		struns[num-1].setAccuracy(struns[num-1].getAccuracy()-1); //��������� ������������� ������
	}
}


}