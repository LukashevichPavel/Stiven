package by.htp.library.dz;



public class Magazine extends PrintedEdition {
	public Magazine(){
		super();
	}
	public Magazine(String type, String title, double price){
		super(type, title, price);
	}
}
